import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { PracticeAreasComponent } from './practice-areas/practice-areas.component';
import { WoncasesComponent } from './woncases/woncases.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { MakeanapointmentComponent } from './makeanapointment/makeanapointment.component';
import { BlogComponent } from './blog/blog.component';


const appRoutesConfig: Routes = [
{ path:"home",component:HomeComponent},
{ path:"practice-areas",component:PracticeAreasComponent},
{ path:"woncases",component:WoncasesComponent},
{ path:"blog",component:BlogComponent},
{ path:"about", component:AboutComponent},
{ path:"contact",component:ContactComponent},
{ path:"makeanapointment",component:MakeanapointmentComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    HomeComponent,
    PracticeAreasComponent,
    WoncasesComponent,
    AboutComponent,
    ContactComponent,
    MakeanapointmentComponent,
    BlogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutesConfig)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
