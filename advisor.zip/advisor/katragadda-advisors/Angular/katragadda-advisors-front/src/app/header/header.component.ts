import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  navItems=[{title:"Home",linkUrl:"home"},
          {title:"Practice Area",linkUrl:"practice-areas"},
          {title:"Won Cases",linkUrl:"woncases"},
          {title:"Blog",linkUrl:"blog"},
          {title:"About",linkUrl:"about"},
          {title:"Contact",linkUrl:"contact"},
          {title:"makeanapointment",linkUrl:"makeanapointment"}
        ]
}
