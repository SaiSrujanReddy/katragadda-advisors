import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakeanapointmentComponent } from './makeanapointment.component';

describe('MakeanapointmentComponent', () => {
  let component: MakeanapointmentComponent;
  let fixture: ComponentFixture<MakeanapointmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakeanapointmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakeanapointmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
