import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'makeanapointment',
  templateUrl: './makeanapointment.component.html',
  styleUrls: ['./makeanapointment.component.css']
})
export class MakeanapointmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
