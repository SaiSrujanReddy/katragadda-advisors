import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'woncases',
  templateUrl: './woncases.component.html',
  styleUrls: ['./woncases.component.css']
})
export class WoncasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
