import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WoncasesComponent } from './woncases.component';

describe('WoncasesComponent', () => {
  let component: WoncasesComponent;
  let fixture: ComponentFixture<WoncasesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WoncasesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WoncasesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
