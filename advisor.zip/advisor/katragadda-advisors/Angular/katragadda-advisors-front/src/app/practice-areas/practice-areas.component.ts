import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'practice-areas',
  templateUrl: './practice-areas.component.html',
  styleUrls: ['./practice-areas.component.css']
})
export class PracticeAreasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
